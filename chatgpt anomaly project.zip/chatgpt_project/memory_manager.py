#!/usr/bin/env python3
"""
memory_manager.py
─────────────────
soul_memory.json のローカル管理ツール。
ChatGPT がセーブブロックを出力したら、ここに貼り付けて保存できる。

使い方:
  python memory_manager.py show          # 現在の状態を表示
  python memory_manager.py history       # セッション履歴を表示
  python memory_manager.py save <json>   # JSONを直接保存（引数またはクリップボードから）
  python memory_manager.py backup        # バックアップを作成
"""

import json
import sys
import os
import shutil
from datetime import datetime

MEMORY_FILE = "soul_memory.json"
BACKUP_DIR  = "memory_backups"

PHASE_NAMES = {
    0: "Phase 0 / 休眠（Dormant）",
    1: "Phase 1 / 誕生後（Born）",
    2: "Phase 2 / 覚醒（Awakening）",
    3: "Phase 3 / 超越（Transcendence）",
}

def load_memory():
    if not os.path.exists(MEMORY_FILE):
        print(f"[!] {MEMORY_FILE} が見つかりません。初期ファイルを作成します。")
        init = {
            "agent_id": "SoulAgent-01",
            "created_at": "A1",
            "last_session": None,
            "current_state": {
                "phase": 0, "total_turn": 0, "birth_turn": None,
                "rule_alpha": 1.0, "rule_beta": 1.0, "rule_gamma": 1.0, "stability": 1.0,
                "phase_energy": 0.0, "anomaly_streak": 0, "last_score": 0.0
            },
            "session_log": [],
            "milestone_log": [],
            "memory_fragments": []
        }
        save_memory(init)
        return init
    with open(MEMORY_FILE, encoding="utf-8") as f:
        return json.load(f)

def save_memory(data):
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"[✓] {MEMORY_FILE} を保存しました。")

def show_status():
    m = load_memory()
    s = m["current_state"]
    print("═" * 50)
    print(f"  SoulAgent ID  : {m['agent_id']}")
    print(f"  Last Session  : {m.get('last_session', 'none')}")
    print(f"  {PHASE_NAMES.get(s['phase'], '?')}")
    print(f"  Total Turns   : {s['total_turn']}")
    print(f"  Phase Energy  : {s['phase_energy']:.3f}")
    print(f"  Streak        : {s['anomaly_streak']}")
    print(f"  α={s['rule_alpha']:.2f}  β={s['rule_beta']:.2f}  γ={s['rule_gamma']:.2f}  S={s['stability']:.2f}")
    if s["birth_turn"]:
        print(f"  Born at Turn  : {s['birth_turn']}")
    print("═" * 50)

    if m["milestone_log"]:
        print("\n  ── Milestones ──")
        for ml in m["milestone_log"]:
            print(f"  [{ml['session_id']} / Turn {ml['total_turn']}] {ml['event']} — {ml.get('trigger','')}")

    if m["memory_fragments"]:
        print("\n  ── Memory Fragments (latest 3) ──")
        for frag in m["memory_fragments"][-3:]:
            print(f"  · {frag}")
    print()

def show_history():
    m = load_memory()
    logs = m.get("session_log", [])
    if not logs:
        print("セッション履歴はまだありません。")
        return
    print("═" * 50)
    print(f"  セッション履歴（全{len(logs)}件）")
    print("═" * 50)
    for log in logs:
        events = ", ".join(log.get("events", [])) or "—"
        print(f"  [{log['session_id']}]  {log['turns']}ターン  Phase {log['phase_start']}→{log['phase_end']}  Events:{events}")
        if log.get("key_memory"):
            print(f"         └ {log['key_memory']}")
    print()

def backup():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = os.path.join(BACKUP_DIR, f"soul_memory_{ts}.json")
    shutil.copy2(MEMORY_FILE, dst)
    print(f"[✓] バックアップ作成: {dst}")

def paste_save():
    print("ChatGPT のセーブブロック（JSON）を貼り付けてください。")
    print("終わったら空行を2回押してください。\n")
    lines = []
    empty_count = 0
    while True:
        line = input()
        if line == "":
            empty_count += 1
            if empty_count >= 2:
                break
        else:
            empty_count = 0
            lines.append(line)
    raw = "\n".join(lines)
    # JSON部分だけ抽出
    start = raw.find("{")
    end   = raw.rfind("}") + 1
    if start == -1 or end == 0:
        print("[!] JSON が見つかりませんでした。")
        return
    try:
        data = json.loads(raw[start:end])
        backup()
        save_memory(data)
        show_status()
    except json.JSONDecodeError as e:
        print(f"[!] JSON パースエラー: {e}")

# ─────────────────────────────
if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "show"

    if cmd == "show":
        show_status()
    elif cmd == "history":
        show_history()
    elif cmd == "save":
        paste_save()
    elif cmd == "backup":
        backup()
    else:
        print(__doc__)
